# Project Requirements & Setup Guide

To run this TinyML Predictive Maintenance project on a fresh PC, you will need to download and install the following hardware components, software tools, and libraries.

## 1. Hardware Requirements
*   **ESP32 Development Board** (e.g., ESP32 WROOM)
*   **INMP441 I2S Microphone** (for capturing acoustic data)
*   **1-Channel Relay Module** (Active-Low or Active-High depending on your model)
*   **SH1106 1.3" OLED Display** (I2C)
*   **Small DC Motor** (with a fan blade or wheel attached to simulate imbalance)
*   Jumper wires and a breadboard
*   Micro-USB or USB-C cable (for programming and powering the ESP32)

## 2. Software Requisites

### A. For the ESP32 (Microcontroller)
You need the Arduino IDE to program the ESP32.
1.  **Download:** [Arduino IDE (v2.x recommended)](https://www.arduino.cc/en/software)
2.  **ESP32 Board Package:** Open Arduino IDE -> File -> Preferences -> Add `https://dl.espressif.com/dl/package_esp32_index.json` to Additional Boards Manager URLs. Then go to Tools -> Board -> Boards Manager and install "esp32".
3.  **Arduino Libraries (Install via Library Manager in Arduino IDE):**
    *   `PubSubClient` (for MQTT communication)
    *   `ArduinoJson` (for formatting telemetry data)
    *   `Adafruit GFX Library` (for the OLED display)
    *   `Adafruit SH110X` (for the OLED display driver)
4.  **Edge Impulse Library:** You must generate and download the trained C++ library from your [Edge Impulse Studio](https://studio.edgeimpulse.com/) project and include it in the Arduino IDE as a `.ZIP` library.

### B. For the Data Collection GUI (Python)
The data collection tool is written in Python and uses a PyQt5 graphical interface.
1.  **Download:** [Python 3.8+ (Make sure to check "Add Python to PATH" during installation)](https://www.python.org/downloads/)
2.  **Python Libraries:** Open your terminal or command prompt and install the required packages by running:
    ```bash
    pip install numpy scipy sounddevice pyserial PyQt5 pyqtgraph
    ```

### C. For the Web Dashboard
The dashboard uses standard web technologies.
1.  **Web Browser:** Any modern web browser (Chrome, Firefox, Edge).
2.  **Node.js (Optional but Recommended):** To avoid CORS (Cross-Origin Resource Sharing) security errors when loading files locally, it is highly recommended to run a local development server. 
    *   Download [Node.js](https://nodejs.org/)
    *   Run `npx http-server` in the `dashboard/` directory to host it.

## 3. Cloud Services
*   **Edge Impulse Account:** Required to train the TinyML acoustic model.
*   **MQTT Broker:** The project currently uses `broker.hivemq.com` (a free public broker). No download required, but an internet connection is necessary for the ESP32 and Dashboard to communicate.
