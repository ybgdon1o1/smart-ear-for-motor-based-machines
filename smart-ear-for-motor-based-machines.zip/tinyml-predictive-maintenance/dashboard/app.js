/* ============================================================
   TinyML Predictive Maintenance Dashboard JavaScript Logic
   ============================================================ */

document.addEventListener("DOMContentLoaded", () => {
  
  // ==================== Configuration & State ====================
  const config = {
    updateIntervalMs: 200,      // Charts update rate
    telemetryLength: 30,        // Number of points in scrolling chart
    historyLength: 15,          // Number of points in history chart
  };

  let systemState = {
    dashboardMode: "sim",      // "sim" or "live"
    mqttConnected: false,
    espOnline: true,
    motorOn: true,
    relaySafe: true,
    acousticEnv: "normal",     // "normal" or "noisy"
    motorHealth: "balanced",   // "balanced" or "imbalanced"
    
    // Telemetry
    soundLevel: 450,
    soundAvg: 410,
    soundPeak: 1200,
    
    // TinyML
    prediction: "NORMAL",      // "NORMAL" or "IMBALANCE"
    confidence: 99.4,
    anomalyScore: 0.02,
    
    // Maintenance
    totalRuntimeSec: 0,
    faultCount: 0,
    lastFaultTime: "None",
    continuousFaults: 0        // Tracks consecutive imbalance predictions
  };

  let telemetryChart, anomalyChart;
  let simulatedTime = 0;
  let chartsTimer, stateTimer, clockTimer;

  // DOM Elements
  const elEspStatusBadge = document.getElementById("esp-status-badge");
  const elEspStatusText = document.getElementById("esp-status-text");
  const elCurrentTime = document.getElementById("current-time");
  
  const elValSoundLevel = document.getElementById("val-sound-level");
  const elValSoundAvg = document.getElementById("val-sound-avg");
  const elValSoundPeak = document.getElementById("val-sound-peak");
  
  const elValConfidence = document.getElementById("val-confidence");
  const elValPredClass = document.getElementById("val-pred-class");
  
  const elTextMotorState = document.getElementById("text-motor-state");
  const elIconMotor = document.getElementById("icon-motor");
  
  const elTextRelayState = document.getElementById("text-relay-state");
  const elIconRelay = document.getElementById("icon-relay");
  
  const elFaultIndicatorCard = document.getElementById("fault-indicator-card");
  const elFaultIndicatorPulse = document.getElementById("fault-indicator-pulse");
  const elFaultIndicatorTitle = document.getElementById("fault-indicator-title");
  const elFaultIndicatorDesc = document.getElementById("fault-indicator-desc");
  const elValLastScan = document.getElementById("val-last-scan");
  
  const elDiagMic = document.getElementById("diag-mic");
  const elDiagOled = document.getElementById("diag-oled");
  const elDiagRelay = document.getElementById("diag-relay");
  const elDiagSerial = document.getElementById("diag-serial");
  
  const elStatRuntime = document.getElementById("stat-runtime");
  const elStatFaultCount = document.getElementById("stat-fault-count");
  const elStatLastFault = document.getElementById("stat-last-fault");
  const elMaintenanceRec = document.getElementById("maintenance-recommendation");
  const elRecText = document.getElementById("rec-text");

  // ==================== Initialize Charts ====================
  const initCharts = () => {
    // Waveform / Raw Acoustic Amplitude Chart
    const ctxTelemetry = document.getElementById('telemetryChart').getContext('2d');
    const initTelemetryData = Array(config.telemetryLength).fill(0);
    const initLabels = Array(config.telemetryLength).fill('');

    telemetryChart = new Chart(ctxTelemetry, {
      type: 'line',
      data: {
        labels: initLabels,
        datasets: [{
          label: 'Acoustic RMS Waveform',
          data: initTelemetryData,
          borderColor: '#00b4d8',
          borderWidth: 2,
          pointRadius: 0,
          fill: true,
          backgroundColor: 'rgba(0, 180, 216, 0.05)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { display: false },
          y: {
            min: 0,
            suggestedMax: 3000,
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#8d99ae', font: { size: 10 } }
          }
        },
        animation: { duration: 100 }
      }
    });

    // Anomaly History & Probability Chart
    const ctxAnomaly = document.getElementById('anomalyChart').getContext('2d');
    const initHistoryData = Array(config.historyLength).fill(0);
    const initHistoryLabels = Array(config.historyLength).fill('');

    anomalyChart = new Chart(ctxAnomaly, {
      type: 'bar',
      data: {
        labels: initHistoryLabels,
        datasets: [
          {
            label: 'Sound Level (RMS)',
            data: initHistoryData,
            backgroundColor: 'rgba(255, 90, 95, 0.4)',
            borderColor: '#ff5a5f',
            borderWidth: 1,
            order: 2
          },
          {
            label: 'Confidence %',
            data: Array(config.historyLength).fill(100),
            borderColor: '#9b5de5',
            borderWidth: 2,
            type: 'line',
            pointRadius: 2,
            fill: false,
            yAxisID: 'y1',
            order: 1,
            tension: 0.2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#f8f9fa', font: { size: 10 } } } },
        scales: {
          x: { display: false },
          y: {
            min: 0,
            suggestedMax: 3000,
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#8d99ae', font: { size: 10 } }
          },
          y1: {
            position: 'right',
            min: 0,
            max: 100,
            grid: { drawOnChartArea: false },
            ticks: { color: '#9b5de5', font: { size: 10 } }
          }
        }
      }
    });
  };

  // ==================== Simulation Logic ====================
  const updateSystemState = () => {
    if (systemState.dashboardMode === "live") {
      return;
    }
    if (!systemState.espOnline) {
      // Offline mode
      systemState.soundLevel = 0;
      systemState.confidence = 0;
      systemState.anomalyScore = 0;
      systemState.prediction = "UNKNOWN";
      return;
    }

    if (!systemState.motorOn) {
      // Motor stopped
      let noiseFloor = systemState.acousticEnv === "noisy" ? 1500 : 300;
      systemState.soundLevel = Math.floor(noiseFloor + Math.random() * 200);
      systemState.prediction = "NORMAL";
      systemState.confidence = 99.8;
      systemState.anomalyScore = 0.01;
      return;
    }

    // Determine target sound level based on motor state and environment
    let targetBase = 600; // Balanced
    let targetRange = 300;

    if (systemState.motorHealth === "imbalanced") {
      targetBase = 11000;
      targetRange = 4000;
    }

    if (systemState.acousticEnv === "noisy") {
      targetBase += 2000;
      targetRange += 1000;
    }

    // Calculate dynamic values
    systemState.soundLevel = Math.floor(targetBase + Math.random() * targetRange);
    
    // Smooth averages and peak calculations
    systemState.soundAvg = Math.floor(systemState.soundAvg * 0.95 + systemState.soundLevel * 0.05);
    
    if (systemState.soundLevel > systemState.soundPeak) {
      systemState.soundPeak = systemState.soundLevel;
    } else {
      systemState.soundPeak = Math.floor(systemState.soundPeak * 0.999 + systemState.soundLevel * 0.001);
    }

    // Simulate TinyML Inference output based on acoustic characteristics
    if (systemState.motorHealth === "imbalanced") {
      systemState.prediction = "IMBALANCE";
      systemState.anomalyScore = parseFloat((0.85 + Math.random() * 0.14).toFixed(3));
      systemState.confidence = parseFloat((92 + Math.random() * 7.8).toFixed(1));
      systemState.continuousFaults++;
    } else {
      systemState.prediction = "NORMAL";
      systemState.anomalyScore = parseFloat((0.01 + Math.random() * 0.05).toFixed(3));
      systemState.confidence = parseFloat((98.5 + Math.random() * 1.4).toFixed(1));
      systemState.continuousFaults = 0;
    }

    // Auto-Relay Trip Logic:
    // If 3 consecutive seconds (approx 15 ticks) of severe anomaly occur:
    if (systemState.continuousFaults > 12 && systemState.relaySafe) {
      triggerSafetyShutdown();
    }
  };

  const triggerSafetyShutdown = () => {
    systemState.relaySafe = false;
    systemState.motorOn = false;
    systemState.faultCount++;
    
    let now = new Date();
    systemState.lastFaultTime = now.toLocaleTimeString();

    // Log the simulated ESP32 MQTT packet showing shutdown trip
    console.warn("SAFETY TRIP: TinyML detected persistent imbalance. Safety Relay opened to stop DC Motor.", getESP32DataPacket());
  };

  const resetSystemDemo = () => {
    if (systemState.dashboardMode === "live") {
      publishMqttCommand("RESET");
      return;
    }
    systemState.motorOn = true;
    systemState.relaySafe = true;
    systemState.motorHealth = "balanced";
    systemState.continuousFaults = 0;
    systemState.soundPeak = 1200;
    systemState.soundAvg = 410;
    
    // Sync tab button UI
    document.getElementById("btn-motor-normal").classList.add("active");
    document.getElementById("btn-motor-fault").classList.remove("active");
    
    console.log("Demo reset: Motor restarted. Safety relay armed.", getESP32DataPacket());
  };

  // ==================== UI Updates ====================
  const updateUI = () => {
    // Current Time
    let now = new Date();
    elCurrentTime.innerText = now.toLocaleTimeString();

    updateMqttStatusUI();

    // ESP Link
    if (systemState.espOnline) {
      elEspStatusText.innerText = "CONNECTED";
      elEspStatusBadge.querySelector(".status-dot").className = "status-dot online";
      
      elDiagMic.className = "status green";
      elDiagMic.innerHTML = '<i class="fa-solid fa-circle-check"></i> Operational';
      elDiagOled.className = "status green";
      elDiagOled.innerHTML = '<i class="fa-solid fa-circle-check"></i> Connected';
      elDiagRelay.className = "status green";
      elDiagRelay.innerHTML = '<i class="fa-solid fa-circle-check"></i> Enabled';
      elDiagSerial.className = "status green";
      elDiagSerial.innerHTML = '<i class="fa-solid fa-circle-check"></i> 921600 Baud';
    } else {
      elEspStatusText.innerText = "OFFLINE";
      elEspStatusBadge.querySelector(".status-dot").className = "status-dot offline";
      
      elDiagMic.className = "status red";
      elDiagMic.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Offline';
      elDiagOled.className = "status red";
      elDiagOled.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Offline';
      elDiagRelay.className = "status red";
      elDiagRelay.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Offline';
      elDiagSerial.className = "status red";
      elDiagSerial.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Terminated';
    }

    // Telemetry Values
    elValSoundLevel.innerText = systemState.soundLevel.toLocaleString();
    elValSoundAvg.innerText = systemState.soundAvg.toLocaleString();
    elValSoundPeak.innerText = systemState.soundPeak.toLocaleString();
    
    elValConfidence.innerText = systemState.espOnline ? systemState.confidence : "0.0";
    elValPredClass.innerText = systemState.prediction;

    // Motor UI State
    if (systemState.motorOn && systemState.espOnline) {
      elTextMotorState.innerText = "RUNNING";
      elTextMotorState.className = "status-text state-on";
      elIconMotor.className = "card-icon green spin-animation";
    } else {
      elTextMotorState.innerText = "STOPPED";
      elTextMotorState.className = "status-text state-off";
      elIconMotor.className = "card-icon red";
    }

    // Relay UI State
    if (systemState.relaySafe && systemState.espOnline) {
      elTextRelayState.innerText = "CLOSED (SAFE)";
      elTextRelayState.className = "status-text state-on";
      elIconRelay.className = "card-icon green";
      elIconRelay.innerHTML = '<i class="fa-solid fa-toggle-on"></i>';
    } else {
      elTextRelayState.innerText = "OPENED (TRIPPED)";
      elTextRelayState.className = "status-text state-off";
      elIconRelay.className = "card-icon red";
      elIconRelay.innerHTML = '<i class="fa-solid fa-toggle-off"></i>';
    }

    // Fault Display Panel
    if (!systemState.espOnline) {
      elFaultIndicatorCard.className = "card fault-panel";
      elFaultIndicatorTitle.innerText = "LINK LOST";
      elFaultIndicatorDesc.innerText = "Check serial interface or ESP32 power line.";
    } else if (!systemState.relaySafe) {
      elFaultIndicatorCard.className = "card fault-panel fault";
      elFaultIndicatorTitle.innerText = "TRIPPED SHUTDOWN";
      elFaultIndicatorDesc.innerText = "Relay tripped to protect DC motor from imbalance structural failure.";
    } else if (systemState.prediction === "IMBALANCE") {
      elFaultIndicatorCard.className = "card fault-panel fault";
      elFaultIndicatorTitle.innerText = "FAULT WARNING";
      elFaultIndicatorDesc.innerText = "Acoustic patterns indicate rotor imbalance. Shutdown timer pending.";
    } else {
      elFaultIndicatorCard.className = "card fault-panel normal";
      elFaultIndicatorTitle.innerText = "NORMAL";
      elFaultIndicatorDesc.innerText = "Motor acoustic vibration signature is normal.";
    }
    
    elValLastScan.innerText = now.toLocaleTimeString();

    // Maintenance Stats
    elStatRuntime.innerText = formatTime(systemState.totalRuntimeSec);
    elStatFaultCount.innerText = systemState.faultCount;
    elStatLastFault.innerText = systemState.lastFaultTime;

    // Recommendations box
    if (!systemState.relaySafe) {
      elMaintenanceRec.className = "recommendation-box alarm";
      elRecText.innerHTML = "<strong>CRITICAL ACTION:</strong> Motor halted due to high acoustic vibration. Inspect fan blade mounts, verify tape weights, and secure structural brackets before restarting.";
    } else if (systemState.prediction === "IMBALANCE") {
      elMaintenanceRec.className = "recommendation-box alarm";
      elRecText.innerHTML = "<strong>WARNING:</strong> TinyML detecting anomaly. Auto-shutdown in progress. Remove tape weights or check motor shaft coupling.";
    } else {
      elMaintenanceRec.className = "recommendation-box";
      elRecText.innerHTML = "System running healthy. Next regular inspection recommended in 240 operating hours.";
    }
  };

  // Helper formats
  const formatTime = (secs) => {
    let h = Math.floor(secs / 3600).toString().padStart(2, '0');
    let m = Math.floor((secs % 3600) / 60).toString().padStart(2, '0');
    let s = (secs % 60).toString().padStart(2, '0');
    return `${h}h ${m}m ${s}s`;
  };

  // ==================== JSON Packet Format ====================
  // This matches the format that the ESP32 uploads via MQTT or WebSockets
  const getESP32DataPacket = () => {
    return {
      timestamp: Date.now(),
      esp32_uptime_sec: systemState.totalRuntimeSec,
      sound_level_rms: systemState.soundLevel,
      sound_avg_rms: systemState.soundAvg,
      sound_peak_rms: systemState.soundPeak,
      tinyml_pred: systemState.prediction,
      tinyml_conf: systemState.prediction === "UNKNOWN" ? 0 : systemState.confidence,
      anomaly_score: systemState.anomalyScore,
      motor_state: (systemState.motorOn && systemState.espOnline) ? 1 : 0,
      relay_state: (systemState.relaySafe && systemState.espOnline) ? 1 : 0,
      total_faults: systemState.faultCount
    };
  };

  // ==================== Update Charts Data ====================
  const updateCharts = () => {
    if (!telemetryChart || !anomalyChart) return;

    // 1. Update Waveform Chart
    let data = telemetryChart.data.datasets[0].data;
    data.shift();
    
    // Synthesize visual waveform based on states
    let baseWave = systemState.soundLevel;
    let amplitude = systemState.motorOn ? (systemState.motorHealth === "imbalanced" ? 5000 : 250) : 50;
    
    simulatedTime += 0.5;
    let waveValue;
    if (systemState.dashboardMode === "live") {
      let jitter = systemState.motorOn ? (Math.random() - 0.5) * (baseWave * 0.2) : (Math.random() - 0.5) * 50;
      waveValue = baseWave + jitter;
    } else {
      waveValue = baseWave + Math.sin(simulatedTime) * amplitude + (Math.random() - 0.5) * (amplitude * 0.8);
    }
    if (waveValue < 0) waveValue = 0;
    
    data.push(Math.round(waveValue));
    telemetryChart.update();

    // 2. Update Anomaly History Chart (updates slightly slower, every 1s)
    if (Math.round(simulatedTime) % 2 === 0) {
      // Sound Level Dataset
      let anomalyData = anomalyChart.data.datasets[0].data;
      anomalyData.shift();
      anomalyData.push(systemState.espOnline ? systemState.soundLevel : 0);

      // Confidence Dataset
      let confData = anomalyChart.data.datasets[1].data;
      confData.shift();
      confData.push(systemState.espOnline ? systemState.confidence : 0);

      anomalyChart.update();

      // Log simulated serial data frame once in a while to inspect data flow
      if (Math.round(simulatedTime) % 10 === 0) {
        console.log("ESP32 Data Frame Stream (JSON over MQTT/WebSockets):", JSON.stringify(getESP32DataPacket(), null, 2));
      }
    }
  };

  // ==================== Event Listeners ====================
  const setupEventListeners = () => {
    // Demo Reset
    document.getElementById("btn-reset-demo").addEventListener("click", resetSystemDemo);

    // Environment
    document.getElementById("btn-env-normal").addEventListener("click", (e) => {
      systemState.acousticEnv = "normal";
      setActiveTab(e.target);
    });
    document.getElementById("btn-env-noisy").addEventListener("click", (e) => {
      systemState.acousticEnv = "noisy";
      setActiveTab(e.target);
    });

    // Motor Health
    document.getElementById("btn-motor-normal").addEventListener("click", (e) => {
      systemState.motorHealth = "balanced";
      if (!systemState.relaySafe) {
        resetSystemDemo();
      }
      setActiveTab(e.target);
    });
    document.getElementById("btn-motor-fault").addEventListener("click", (e) => {
      systemState.motorHealth = "imbalanced";
      setActiveTab(e.target);
    });

    // Connection
    document.getElementById("btn-conn-online").addEventListener("click", (e) => {
      systemState.espOnline = true;
      setActiveTab(e.target);
    });
    document.getElementById("btn-conn-offline").addEventListener("click", (e) => {
      systemState.espOnline = false;
      setActiveTab(e.target);
    });

    // Dashboard Mode
    document.getElementById("btn-mode-live").addEventListener("click", (e) => {
      systemState.dashboardMode = "live";
      setActiveTab(e.target);
      toggleSimulatorControls(true);
      console.log("[DASHBOARD] Switched to LIVE (MQTT) mode");
    });
    document.getElementById("btn-mode-sim").addEventListener("click", (e) => {
      systemState.dashboardMode = "sim";
      setActiveTab(e.target);
      toggleSimulatorControls(false);
      console.log("[DASHBOARD] Switched to SIMULATOR mode");
    });

    // Manual Relay Controls (Live Mode)
    document.getElementById("btn-manual-on").addEventListener("click", () => {
      if (systemState.dashboardMode === "live") publishMqttCommand("relay_on");
      else alert("Switch to Live Mode first to control the physical relay.");
    });
    document.getElementById("btn-manual-off").addEventListener("click", () => {
      if (systemState.dashboardMode === "live") publishMqttCommand("relay_off");
      else alert("Switch to Live Mode first to control the physical relay.");
    });
    document.getElementById("btn-manual-reset").addEventListener("click", () => {
      if (systemState.dashboardMode === "live") publishMqttCommand("reset");
      else alert("Switch to Live Mode first to control the physical relay.");
    });
  };

  const setActiveTab = (selectedButton) => {
    const parent = selectedButton.parentElement;
    parent.querySelectorAll(".btn-tab").forEach(btn => btn.classList.remove("active"));
    selectedButton.classList.add("active");
  };

  const toggleSimulatorControls = (disableSim) => {
    const simPanel = document.querySelector(".simulator-card");
    if (simPanel) {
      const groups = simPanel.querySelectorAll(".control-group:not(:first-child)");
      groups.forEach(group => {
        const isLiveGroup = group.querySelector("#btn-manual-on") !== null;
        const tabs = group.querySelectorAll(".btn-tab");
        
        tabs.forEach(tab => {
          if (isLiveGroup) {
            // Live controls are enabled only in Live Mode (disableSim == true)
            tab.style.opacity = disableSim ? "1" : "0.5";
            tab.style.pointerEvents = disableSim ? "auto" : "none";
          } else {
            // Simulator controls are enabled only in Sim Mode (disableSim == false)
            tab.style.opacity = disableSim ? "0.5" : "1";
            tab.style.pointerEvents = disableSim ? "none" : "auto";
          }
        });
      });
    }
  };

  // ==================== MQTT Client Setup ====================
  const initMQTT = () => {
    const brokerUrl = "wss://broker.hivemq.com:8884/mqtt";
    console.log(`[MQTT] Connecting to ${brokerUrl}...`);
    
    mqttClient = mqtt.connect(brokerUrl, {
      clientId: "web-dash-" + Math.random().toString(16).substring(2, 10),
      clean: true,
      connectTimeout: 4000
    });
    
    mqttClient.on("connect", () => {
      console.log("[MQTT] Connected to broker successfully!");
      systemState.mqttConnected = true;
      updateMqttStatusUI();
      
      mqttClient.subscribe("tinyml-predictive-maintenance/telemetry", (err) => {
        if (!err) {
          console.log("[MQTT] Subscribed to telemetry topic");
        } else {
          console.error("[MQTT] Subscription error:", err);
        }
      });
    });
    
    mqttClient.on("message", (topic, message) => {
      if (systemState.dashboardMode !== "live") return;
      
      try {
        const payload = JSON.parse(message.toString());
        systemState.espOnline = true;
        systemState.soundLevel = payload.sound_level || 0;
        systemState.prediction = payload.prediction || "NORMAL";
        systemState.confidence = payload.confidence || 0.0;
        systemState.anomalyScore = payload.anomaly_score !== undefined ? payload.anomaly_score : 0.0;
        systemState.motorOn = payload.motor_state === 1;
        systemState.relaySafe = payload.relay_state === 1;
        
        if (payload.uptime !== undefined) {
          systemState.totalRuntimeSec = payload.uptime;
        }
        
        if (!systemState.relaySafe && systemState.continuousFaults <= 12) {
          systemState.continuousFaults = 13;
          systemState.faultCount = payload.total_faults || (systemState.faultCount + 1);
          let now = new Date();
          systemState.lastFaultTime = now.toLocaleTimeString();
        } else if (systemState.relaySafe) {
          systemState.continuousFaults = 0;
        }
        
        updateUI();
      } catch (err) {
        console.error("[MQTT] Failed to parse message:", err);
      }
    });
    
    mqttClient.on("close", () => {
      console.warn("[MQTT] Connection closed");
      systemState.mqttConnected = false;
      updateMqttStatusUI();
    });
    
    mqttClient.on("error", (err) => {
      console.error("[MQTT] Connection error:", err);
      systemState.mqttConnected = false;
      updateMqttStatusUI();
    });
  };

  const updateMqttStatusUI = () => {
    const elMqttBadge = document.getElementById("mqtt-status-badge");
    const elMqttText = document.getElementById("mqtt-status-text");
    if (elMqttBadge && elMqttText) {
      if (systemState.mqttConnected) {
        elMqttText.innerText = "CONNECTED";
        elMqttBadge.querySelector(".status-dot").className = "status-dot online";
      } else {
        elMqttText.innerText = "OFFLINE";
        elMqttBadge.querySelector(".status-dot").className = "status-dot offline";
      }
    }
  };

  const publishMqttCommand = (cmd) => {
    if (mqttClient && systemState.mqttConnected) {
      mqttClient.publish("tinyml-predictive-maintenance/cmd", cmd);
      console.log(`[MQTT] Published command: ${cmd}`);
    }
  };

  // ==================== System Timers ====================
  const startTimers = () => {
    // 1. Clock and runtime tracker
    clockTimer = setInterval(() => {
      if (systemState.espOnline && systemState.motorOn) {
        systemState.totalRuntimeSec++;
      }
      updateUI();
    }, 1000);

    // 2. State machine loop
    stateTimer = setInterval(updateSystemState, 250);

    // 3. Chart scroll loop
    chartsTimer = setInterval(updateCharts, config.updateIntervalMs);
  };

  // Start Everything
  initCharts();
  setupEventListeners();
  initMQTT();
  startTimers();
  updateUI();
  
  console.log("TinyML Predictive Maintenance Simulator Initialized.");
  console.log("Sample ESP32 Data Frame Format:", getESP32DataPacket());

});
