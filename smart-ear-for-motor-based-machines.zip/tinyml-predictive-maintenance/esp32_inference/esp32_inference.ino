// ============================================================
// Safety: Increase TFLite scratch buffer slot limit
// Must be defined BEFORE the inferencing header.
// ============================================================
#define EI_MAX_SCRATCH_BUFFER_COUNT  32

#include <iotpj1_inferencing.h>

/*
 * ============================================================
 * TinyML Predictive Maintenance - Inference System v3
 * ============================================================
 *
 * Hardware:
 *   - ESP32 Dev Module
 *   - INMP441 I2S Microphone (WS:15, SCK:14, SD:32)
 *   - SH1106 1.3" OLED Display (I2C: 0x3C)
 *   - 1-Channel Relay Module (IN: GPIO27, Active-LOW)
 *   - DC Motor with Paper Fan
 *
 * Memory Strategy (v3 — Continuous Classifier):
 *   The model needs 80000 samples (160KB) which is too large
 *   to buffer on ESP32 (280KB total heap). The standard
 *   classifier also needs ~50KB+ for MFCC feature matrix.
 *
 *   Solution: Use run_classifier_continuous() which processes
 *   audio in small slices (EI_CLASSIFIER_SLICE_SIZE). This
 *   only needs ~20-40KB for the slice buffer, leaving plenty
 *   of heap for DSP computation.
 *
 * Detection Logic:
 *   If "imbalance" confidence > 80% for 3 consecutive full
 *   windows, the relay cuts motor power.
 *
 * ============================================================
 */

#include <driver/i2s.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// ===================== Configuration ========================
const char* WIFI_SSID   = "iphone";
const char* WIFI_PASS   = "abcc1223";
const char* MQTT_BROKER = "broker.hivemq.com";
const int   MQTT_PORT   = 1883;
const char* TOPIC_TELEM = "tinyml-predictive-maintenance/telemetry";
const char* TOPIC_CMD   = "tinyml-predictive-maintenance/cmd";

// ===================== Pin Definitions ======================
#define I2S_WS    15    // INMP441 Word Select
#define I2S_SCK   14    // INMP441 Serial Clock
#define I2S_SD    32    // INMP441 Serial Data
#define RELAY_PIN 27    // Relay control (Active-LOW)

// ===================== Display ==============================
#define SCREEN_W  128
#define SCREEN_H  64
#define OLED_ADDR 0x3C

// ===================== Detection Thresholds =================
#define CONFIDENCE_THRESHOLD  0.90f   // 90% – raised to reduce false triggers from ambient noise
#define FAULTS_REQUIRED       5    // 4 consecutive windows before trip

// ===================== Global Objects =======================
Adafruit_SH1106G oled(SCREEN_W, SCREEN_H, &Wire, -1);

// Slice buffer - dynamically allocated, much smaller than full window
static int16_t* sliceBuffer = nullptr;

// System state
enum State { RUNNING, FAULT_WARNING, MOTOR_STOPPED };
State    state = RUNNING;
int      consecutiveFaults = 0;
float    lastConf = 0.0f;
String   lastPred = "---";
unsigned long infCount = 0;       // Full window count
unsigned long sliceCount = 0;     // Slice count
bool     motorIsOn = true;
float    lastRms = 0.0f;

// Label indices (found dynamically from model)
int idxNormal = -1;
int idxLooseBearing = -1;

// MQTT command flags
bool pendingReset = false;
int  pendingRelayCmd = -1;  // -1=none, 0=OFF, 1=ON

// WiFi/MQTT clients (only alive during publish window)
WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);

// ===================== Audio Callback =======================
// Edge Impulse calls this to get slice audio data for DSP.
static int getSliceData(size_t offset, size_t length, float *out) {
  for (size_t i = 0; i < length; i++) {
    // Edge Impulse expects raw PCM values (e.g., 15000, -8000). 
    // Do NOT divide by 32768, otherwise the signal becomes too small and gets zeroed out.
    out[i] = (float)sliceBuffer[offset + i];
  }
  return 0;
}

// ===================== I2S Microphone =======================
void initI2S() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = (uint32_t)EI_CLASSIFIER_FREQUENCY,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT, // INMP441 requires 32-bit slot
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 4,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };

  i2s_pin_config_t pins = {
    .bck_io_num = I2S_SCK,
    .ws_io_num = I2S_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = I2S_SD
  };

  ESP_ERROR_CHECK(i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL));
  ESP_ERROR_CHECK(i2s_set_pin(I2S_NUM_0, &pins));
  delay(500);

  // Flush startup noise
  int32_t trash[256];
  size_t br;
  for (int i = 0; i < 10; i++) {
    i2s_read(I2S_NUM_0, trash, sizeof(trash), &br, portMAX_DELAY);
  }
  Serial.println("[I2S] OK");
}

// ===================== OLED Helpers =========================
void oledShowStatus(const char* status, float conf, bool isFault) {
  oled.clearDisplay();
  oled.setTextColor(SH110X_WHITE);

  // Header
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  if (isFault) {
    oled.println("!! ALERT !!");
  } else {
    oled.println("TinyML PredMaint");
  }
  oled.drawLine(0, 10, 128, 10, SH110X_WHITE);

  // Main status
  oled.setTextSize(2);
  oled.setCursor(0, 14);
  oled.println(status);

  // Details
  oled.setTextSize(1);
  oled.setCursor(0, 34);
  oled.print("Conf: ");
  oled.print(conf * 100, 1);
  oled.println("%");

  oled.setCursor(0, 44);
  oled.print("Motor: ");
  oled.println(motorIsOn ? "RUNNING" : "STOPPED");

  // Confidence bar
  int barW = constrain((int)(conf * 100), 0, 100);
  oled.drawRect(0, 55, 100, 8, SH110X_WHITE);
  oled.fillRect(0, 55, barW, 8, SH110X_WHITE);

  // Inference count
  oled.setCursor(104, 55);
  oled.print("#");
  oled.print(infCount);

  oled.display();
}

void oledShowMessage(const char* line1, const char* line2, const char* line3 = nullptr) {
  oled.clearDisplay();
  oled.setTextColor(SH110X_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.println(line1);
  oled.setCursor(0, 12);
  oled.println(line2);
  if (line3) {
    oled.setCursor(0, 24);
    oled.println(line3);
  }
  oled.display();
}

// ===================== Relay / Motor ========================
void setMotor(bool on) {
  motorIsOn = on;
  digitalWrite(RELAY_PIN, on ? HIGH : LOW);  // Active-HIGH relay (Requires jumper on 'H')
  Serial.printf("[MOTOR] %s\n", on ? "ON" : "OFF");
}

// ===================== Find Model Labels ====================
void findLabels() {
  Serial.println("[MODEL] Scanning labels...");
  for (size_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
    String lbl = ei_classifier_inferencing_categories[i];
    Serial.printf("[MODEL]   [%d] %s\n", i, lbl.c_str());
    lbl.toLowerCase();
    if (lbl == "normal")         idxNormal = i;
    else if (lbl == "loose_bearing") idxLooseBearing = i;
  }
  Serial.printf("[MODEL] normal=%d, loose_bearing=%d\n", idxNormal, idxLooseBearing);

  if (idxNormal == -1 || idxLooseBearing == -1) {
    Serial.println("[MODEL] WARNING: Expected labels not found!");
  }
}

// ===================== Capture One Slice ====================
// Captures exactly EI_CLASSIFIER_SLICE_SIZE samples from I2S
void captureSlice() {
  size_t total = 0;
  size_t br;
  int32_t tempBuf[256]; // Temporary 32-bit buffer

  while (total < (size_t)EI_CLASSIFIER_SLICE_SIZE) {
    size_t remaining = (size_t)EI_CLASSIFIER_SLICE_SIZE - total;
    size_t toRead = (remaining < 256) ? remaining : 256;
    
    esp_err_t err = i2s_read(I2S_NUM_0, tempBuf, toRead * sizeof(int32_t), &br, portMAX_DELAY);
    
    if (err == ESP_OK && br > 0) {
      size_t samplesRead = br / sizeof(int32_t);
      for (size_t i = 0; i < samplesRead; i++) {
        // Shift right by 16 to get MSB-aligned 16-bit PCM from the 32-bit slot
        sliceBuffer[total + i] = (int16_t)(tempBuf[i] >> 16);
      }
      total += samplesRead;
    }
  }
}

// Compute RMS of the current slice
float computeSliceRms() {
  double sumSq = 0;
  for (int i = 0; i < EI_CLASSIFIER_SLICE_SIZE; i++) {
    double v = (double)sliceBuffer[i];
    sumSq += v * v;
  }
  // Apply a 5x digital gain multiplier for better visualization on the dashboard
  return sqrt(sumSq / EI_CLASSIFIER_SLICE_SIZE) * 5.0f;
}

// ===================== MQTT Callback ========================
void onMqttMessage(char* topic, byte* payload, unsigned int len) {
  String msg;
  for (unsigned int i = 0; i < len; i++) msg += (char)payload[i];
  Serial.printf("[MQTT] Cmd received: %s\n", msg.c_str());

  msg.toLowerCase();
  msg.trim();

  if (msg.indexOf("reset") >= 0) {
    pendingReset = true;
  } else if (msg.indexOf("relay_on") >= 0 || msg.indexOf("motor_on") >= 0 || msg.indexOf("on") >= 0) {
    pendingRelayCmd = 1;
  } else if (msg.indexOf("relay_off") >= 0 || msg.indexOf("motor_off") >= 0 || msg.indexOf("off") >= 0) {
    pendingRelayCmd = 0;
  }
}

// ===================== WiFi Publish Window ===================
void wifiPublishAndCheck() {
  // Reconnect WiFi if needed
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[NET] Reconnecting WiFi...");
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 3000) {
      delay(100);
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.printf("[NET] Connected (IP: %s)\n", WiFi.localIP().toString().c_str());
    } else {
      Serial.println("[NET] WiFi failed, skipping publish");
      return;
    }
  }

  // Reconnect MQTT if needed
  if (!mqtt.connected()) {
    mqtt.setServer(MQTT_BROKER, MQTT_PORT);
    mqtt.setCallback(onMqttMessage);
    mqtt.setBufferSize(256);
    String clientId = "ESP32-PM-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (mqtt.connect(clientId.c_str())) {
      Serial.println("[MQTT] Connected");
      mqtt.subscribe(TOPIC_CMD);
    } else {
      Serial.printf("[MQTT] Failed (rc=%d)\n", mqtt.state());
      return;
    }
  }

  StaticJsonDocument<256> doc;
  doc["uptime"]       = millis() / 1000;
  doc["sound_level"]  = (int)lastRms;
  doc["prediction"]   = lastPred;
  doc["confidence"]   = (int)(lastConf * 100);
  doc["motor_state"]  = motorIsOn ? 1 : 0;
  doc["relay_state"]  = motorIsOn ? 1 : 0;
  doc["fault_count"]  = consecutiveFaults;
  doc["inf_count"]    = (long)infCount;
  doc["anomaly_score"] = (lastPred == "loose_bearing") ? lastConf : (1.0f - lastConf);

  char buf[256];
  serializeJson(doc, buf);
  mqtt.publish(TOPIC_TELEM, buf);

  // Listen for commands very briefly (e.g., 50ms) to avoid lagging the classifier
  unsigned long listenStart = millis();
  while (millis() - listenStart < 50) {
    mqtt.loop();
    delay(10);
  }
}

// ===================== Handle Pending Commands ==============
void handlePendingCommands() {
  if (pendingReset) {
    pendingReset = false;
    Serial.println("[CMD] RESET received");
    consecutiveFaults = 0;
    state = RUNNING;
    setMotor(true);
    oledShowStatus("RESET!", 0, false);
    delay(1500);
  }

  if (pendingRelayCmd >= 0) {
    bool turnOn = (pendingRelayCmd == 1);
    pendingRelayCmd = -1;
    Serial.printf("[CMD] Manual relay -> %s\n", turnOn ? "ON" : "OFF");
    setMotor(turnOn);
    if (turnOn) {
      consecutiveFaults = 0;
      state = RUNNING;
      oledShowStatus("MANUAL ON", 0, false);
    } else {
      state = MOTOR_STOPPED;
      oledShowStatus("MANUAL OFF", 0, true);
    }
    delay(1500);
  }
}

// ===================== Quick MQTT Check =====================
// Keeps the MQTT client instantly responsive without blocking
void checkMqttQuick() {
  if (WiFi.status() == WL_CONNECTED && mqtt.connected()) {
    mqtt.loop();
    handlePendingCommands();
  }
}

// ===================== Process Results ======================
// Called after each full window (every SLICES_PER_MODEL_WINDOW slices)
void processResults(ei_impulse_result_t &result) {
  infCount++;

  float maxConf = 0;
  int   maxIdx  = 0;

  Serial.printf("\n[INF] === Window #%lu Results ===\n", infCount);
  for (size_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
    Serial.printf("[INF]   %s: %.4f\n",
                  ei_classifier_inferencing_categories[i],
                  result.classification[i].value);
    if (result.classification[i].value > maxConf) {
      maxConf = result.classification[i].value;
      maxIdx = i;
    }
  }

  lastPred = ei_classifier_inferencing_categories[maxIdx];
  lastConf = maxConf;

  // --- DECISION LOGIC ---
  if (idxLooseBearing >= 0 &&
      result.classification[idxLooseBearing].value > CONFIDENCE_THRESHOLD) {

    consecutiveFaults++;
    Serial.printf("[FAULT] Loose Bearing! %d/%d (%.1f%%)\n",
                  consecutiveFaults, FAULTS_REQUIRED,
                  result.classification[idxLooseBearing].value * 100);

    if (consecutiveFaults >= FAULTS_REQUIRED && state != MOTOR_STOPPED) {
      setMotor(false);
      state = MOTOR_STOPPED;
      Serial.println("!!! FAULT CONFIRMED - MOTOR STOPPED !!!");
      oledShowStatus("FAULT!", result.classification[idxLooseBearing].value, true);
    }
    else if (state != MOTOR_STOPPED) {
      state = FAULT_WARNING;
      char buf[20];
      snprintf(buf, sizeof(buf), "WARN %d/%d", consecutiveFaults, FAULTS_REQUIRED);
      oledShowStatus(buf, result.classification[idxLooseBearing].value, false);
    }
  }
  else if (idxNormal >= 0 &&
           result.classification[idxNormal].value > 0.5f) {
    consecutiveFaults = 0;
    if (state != MOTOR_STOPPED) {
      state = RUNNING;
      oledShowStatus("NORMAL", result.classification[idxNormal].value, false);
    }
  }
  else {
    if (state != MOTOR_STOPPED) {
      oledShowStatus("ANALYZE", maxConf, false);
    }
  }

  // Publish telemetry and check commands after each full window
  wifiPublishAndCheck();
  handlePendingCommands();
}

// ===================== Setup ================================
void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);

  Serial.println("=========================================");
  Serial.println("  TinyML Predictive Maintenance v3");
  Serial.println("  (Continuous Classifier - Low Memory)");
  Serial.println("=========================================");
  Serial.printf("[MEM] Boot heap: %u bytes\n", ESP.getFreeHeap());
  Serial.printf("[MEM] MaxBlock:  %u bytes\n", ESP.getMaxAllocHeap());

  // Ensure WiFi is OFF
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(100);

  // --- Print model info ---
  Serial.println("\n[MODEL] Edge Impulse Model Info:");
  Serial.printf("[MODEL]   Labels             : %d\n", EI_CLASSIFIER_LABEL_COUNT);
  Serial.printf("[MODEL]   Frequency           : %d Hz\n", (int)EI_CLASSIFIER_FREQUENCY);
  Serial.printf("[MODEL]   Raw sample count    : %d\n", EI_CLASSIFIER_RAW_SAMPLE_COUNT);
  Serial.printf("[MODEL]   Slice size          : %d samples\n", EI_CLASSIFIER_SLICE_SIZE);
  Serial.printf("[MODEL]   Slices per window   : %d\n", EI_CLASSIFIER_SLICES_PER_MODEL_WINDOW);
  Serial.printf("[MODEL]   Slice buffer bytes  : %d\n",
                EI_CLASSIFIER_SLICE_SIZE * (int)sizeof(int16_t));

  // --- Allocate slice buffer ---
  int sliceBytes = EI_CLASSIFIER_SLICE_SIZE * sizeof(int16_t);
  Serial.printf("[MEM] Allocating slice buffer: %d bytes\n", sliceBytes);

  sliceBuffer = (int16_t*)malloc(sliceBytes);
  if (!sliceBuffer) {
    Serial.println("[FATAL] Cannot allocate slice buffer!");
    while (true) delay(1000);
  }
  Serial.printf("[MEM] Slice buffer OK. Remaining heap: %u, MaxBlock: %u\n",
                ESP.getFreeHeap(), ESP.getMaxAllocHeap());

  // --- Init OLED ---
  Wire.begin(21, 22);
  if (!oled.begin(OLED_ADDR, true)) {
    Serial.println("[OLED] FAILED!");
    while (true);
  }
  oled.clearDisplay();
  oled.display();
  Serial.println("[OLED] OK");

  oledShowMessage("TinyML PredMaint", "v3 Continuous Mode", "Initializing...");

  // --- Init I2S Microphone ---
  initI2S();

  // --- Init Relay (motor starts ON) ---
  pinMode(RELAY_PIN, OUTPUT);
  setMotor(true);

  // --- Find model labels ---
  findLabels();

  Serial.printf("\n[MEM] Setup complete. Heap: %u, MaxBlock: %u\n",
                ESP.getFreeHeap(), ESP.getMaxAllocHeap());
  Serial.printf("[SYS] Will process %d slices per window (%d samples/slice)\n",
                EI_CLASSIFIER_SLICES_PER_MODEL_WINDOW,
                EI_CLASSIFIER_SLICE_SIZE);
  Serial.println("[SYS] Starting continuous inference...\n");

  oledShowStatus("READY", 0, false);
  delay(2000);

  state = RUNNING;
}

// ===================== Main Loop ============================
void loop() {

  // ---- MOTOR STOPPED STATE ----
  if (state == MOTOR_STOPPED) {
    static unsigned long lastBlink = 0;
    static bool blink = false;

    if (millis() - lastBlink > 1000) {
      blink = !blink;
      if (blink) {
        oledShowStatus("FAULT!", lastConf, true);
      } else {
        oled.clearDisplay();
        oled.setTextSize(2);
        oled.setTextColor(SH110X_WHITE);
        oled.setCursor(10, 10);
        oled.println("MOTOR");
        oled.setCursor(10, 30);
        oled.println("STOPPED");
        oled.setTextSize(1);
        oled.setCursor(0, 52);
        oled.println("Serial 'R' or MQTT");
        oled.println("'reset' to restart");
        oled.display();
      }
      lastBlink = millis();
    }

    // Serial reset
    if (Serial.available()) {
      char c = Serial.read();
      if (c == 'R' || c == 'r') {
        Serial.println("[SYS] Serial reset!");
        consecutiveFaults = 0;
        state = RUNNING;
        setMotor(true);
        oledShowStatus("RESET!", 0, false);
        delay(2000);
        return;
      }
    }

    // Check MQTT every 10s for publishing telemetry
    static unsigned long lastMqttCheck = 0;
    if (millis() - lastMqttCheck > 10000) {
      lastMqttCheck = millis();
      wifiPublishAndCheck();
    } else {
      checkMqttQuick(); // Check for incoming commands instantly
    }

    delay(10);
    return;
  }

  // ---- CONTINUOUS INFERENCE ----
  checkMqttQuick(); // Process manual commands between slices

  // Capture one slice of audio
  captureSlice();
  sliceCount++;

  // Compute RMS for this slice
  lastRms = computeSliceRms();

  // Set up signal for this slice
  signal_t signal;
  signal.total_length = EI_CLASSIFIER_SLICE_SIZE;
  signal.get_data = &getSliceData;

  // Run continuous classifier
  ei_impulse_result_t result = { 0 };

  EI_IMPULSE_ERROR err = run_classifier_continuous(&signal, &result, false);

  if (err != EI_IMPULSE_OK) {
    Serial.printf("[INF] Classifier error (%d)\n", err);
    return;
  }

  // Log every slice briefly
  Serial.printf("[SLICE] #%lu (RMS=%.0f) ", sliceCount, lastRms);
  for (size_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
    Serial.printf("%s:%.2f ", ei_classifier_inferencing_categories[i],
                  result.classification[i].value);
  }
  Serial.println();

  // Process results after each full window
  // (every SLICES_PER_MODEL_WINDOW slices = one complete classification)
  if (sliceCount % EI_CLASSIFIER_SLICES_PER_MODEL_WINDOW == 0) {
    processResults(result);
  }
}
