# TinyML Predictive Maintenance — Pin Configuration Guide

> Complete wiring reference for the ESP32 DevKit V1 board used in this project.

---

## 📌 1. INMP441 MEMS Microphone (I2S)

The INMP441 communicates with the ESP32 over the **I2S** digital audio bus.

| INMP441 Pin | ESP32 GPIO | Signal Name | Description |
|:-----------:|:----------:|:-----------:|:------------|
| **WS**      | `GPIO 15`  | Word Select (LRCLK) | Left/Right channel clock. Directly selects L or R channel data. |
| **SCK**     | `GPIO 14`  | Serial Clock (BCLK) | Bit clock that drives data transfer. |
| **SD**      | `GPIO 32`  | Serial Data (DOUT)  | Digital audio data output from the microphone. |
| **VDD**     | `3.3 V`    | Power       | Supply voltage (2.7 V – 3.6 V). |
| **GND**     | `GND`      | Ground      | Common ground. |
| **L/R**     | `GND`      | Channel Select | Tie to **GND** for Left channel (default configuration). |

> [!NOTE]
> The I2S port used is `I2S_NUM_0`. Both the Data Collector and Inference firmware share the same pin assignments.

### I2S Bus Parameters

| Parameter       | Value   |
|:----------------|:--------|
| Sample Rate     | 16 000 Hz (16 kHz) |
| Sample Bits     | 16-bit  |
| DMA Buffer Count| 8       |
| DMA Buffer Length| 512 samples |

---

## 🖥️ 2. SH1106 OLED Display (I2C)

The 1.3″ SH1106 OLED uses the hardware **I2C** bus (Wire library).

| OLED Pin | ESP32 GPIO | Signal Name | Description |
|:--------:|:----------:|:-----------:|:------------|
| **SDA**  | `GPIO 21`  | I2C Data    | Default ESP32 I2C data line. |
| **SCL**  | `GPIO 22`  | I2C Clock   | Default ESP32 I2C clock line. |
| **VCC**  | `3.3 V`    | Power       | Supply voltage. |
| **GND**  | `GND`      | Ground      | Common ground. |

> [!IMPORTANT]
> GPIO 21 (SDA) and GPIO 22 (SCL) are the ESP32's default I2C pins used by the `Wire` library. No explicit pin definition is needed in code.

### Display Parameters

| Parameter     | Value    |
|:--------------|:---------|
| Resolution    | 128 × 64 pixels |
| I2C Address   | `0x3C`   |
| Reset Pin     | `-1` (no hardware reset, uses software reset) |

---

## ⚡ 3. Relay Module (Digital Output)

The relay is used for the **motor safety cutoff** during the Inference phase.

| Relay Pin | ESP32 GPIO | Signal Name | Description |
|:---------:|:----------:|:-----------:|:------------|
| **IN**    | `GPIO 27`  | Relay Control | Control signal from ESP32. |
| **VCC**   | `5 V (Vin)` | Power      | Relay coil power (most modules need 5 V). |
| **GND**   | `GND`      | Ground      | Common ground. |

> [!WARNING]
> The relay is **Active-LOW**. Writing `LOW` to GPIO 27 **energises** the relay (motor OFF). Writing `HIGH` **de-energises** it (motor ON). Ensure your relay module matches this logic or adjust `RELAY_PIN` behaviour in code.

---

## 🔧 4. Full Wiring Summary (ESP32 DevKit V1)

```text
ESP32 DevKit V1
┌──────────────────────────────┐
│                              │
│   GPIO 14 ──── SCK  ──► INMP441 (Serial Clock)
│   GPIO 15 ──── WS   ──► INMP441 (Word Select)
│   GPIO 32 ──── SD   ──► INMP441 (Serial Data)
│                              │
│   GPIO 21 ──── SDA  ──► SH1106 OLED (I2C Data)
│   GPIO 22 ──── SCL  ──► SH1106 OLED (I2C Clock)
│                              │
│   GPIO 27 ──── IN   ──► Relay Module (Motor Cutoff)
│                              │
│   3.3V    ──── VDD  ──► INMP441, OLED
│   5V/Vin  ──── VCC  ──► Relay Module
│   GND     ──── GND  ──► All components
│                              │
└──────────────────────────────┘
```

---

## 🧩 5. Pin Usage At-a-Glance

| GPIO | Direction | Protocol | Connected To | Used In |
|:----:|:---------:|:--------:|:-------------|:--------|
| 14   | Output    | I2S      | INMP441 SCK  | Data Collector + Inference |
| 15   | Output    | I2S      | INMP441 WS   | Data Collector + Inference |
| 32   | Input     | I2S      | INMP441 SD   | Data Collector + Inference |
| 21   | Bidir     | I2C      | OLED SDA     | Data Collector + Inference |
| 22   | Output    | I2C      | OLED SCL     | Data Collector + Inference |
| 27   | Output    | Digital  | Relay IN     | Inference only |

---

## ⚙️ 6. Software Thresholds (Inference Firmware)

These are configurable `#define` values in [esp32_inference.ino](file:///c:/Users/annuk/.gemini/antigravity/scratch/tinyml-predictive-maintenance/esp32_inference/esp32_inference.ino):

| Parameter              | Value | Description |
|:-----------------------|:------|:------------|
| `CONFIDENCE_THRESHOLD` | 0.90 (90%) | Minimum AI confidence to flag a fault. Raised to reduce false triggers from ambient noise. |
| `FAULTS_REQUIRED`      | 4     | Consecutive fault windows needed before relay trips. |

---

> [!TIP]
> All pin assignments are defined at the top of each `.ino` file. If your wiring differs, update the `#define` values in both [esp32_data_collector.ino](file:///c:/Users/annuk/.gemini/antigravity/scratch/tinyml-predictive-maintenance/esp32_data_collector/esp32_data_collector.ino) and [esp32_inference.ino](file:///c:/Users/annuk/.gemini/antigravity/scratch/tinyml-predictive-maintenance/esp32_inference/esp32_inference.ino) to match.
