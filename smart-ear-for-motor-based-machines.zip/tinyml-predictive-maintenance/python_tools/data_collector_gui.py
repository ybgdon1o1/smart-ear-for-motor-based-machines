import sys
import os
import time
import queue
import wave
import struct
import numpy as np
import scipy.signal
import sounddevice as sd
import serial
import serial.tools.list_ports
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QComboBox, QSpinBox, 
                             QDoubleSpinBox, QPushButton, QProgressBar, 
                             QTreeWidget, QTreeWidgetItem, QMessageBox, QFrame)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QFont, QPainter, QColor, QBrush, QLinearGradient
import pyqtgraph as pg

# ======================================================================
# DATA MODEL & CONSTANTS
# ======================================================================

SAMPLE_RATE = 16000
SAMPLE_WIDTH = 2
NUM_CHANNELS = 1

# ======================================================================
# THREADS
# ======================================================================

class SerialReader(QThread):
    connected = pyqtSignal(bool)
    status_updated = pyqtSignal(str)
    recording_started = pyqtSignal()
    recording_ended = pyqtSignal()
    data_received = pyqtSignal(np.ndarray)
    error_occurred = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.ser = None
        self.port = ""
        self.baud = 921600
        self.running = False
        self.binary_mode = False
        self.expected_bytes = 0
        self.command_queue = queue.Queue()

    def connect_port(self, port):
        self.port = port
        self.start()

    def disconnect_port(self):
        self.running = False
        self.wait()

    def send_command(self, cmd):
        self.command_queue.put(cmd)

    def run(self):
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.1)
            self.running = True
            self.connected.emit(True)
            self.status_updated.emit("Connected to " + self.port)
        except Exception as e:
            self.error_occurred.emit(str(e))
            self.connected.emit(False)
            return

        buffer = bytearray()
        
        while self.running:
            # Send commands
            while not self.command_queue.empty():
                cmd = self.command_queue.get()
                try:
                    self.ser.write((cmd + "\n").encode())
                    self.ser.flush()
                except Exception as e:
                    self.error_occurred.emit("Write error: " + str(e))
                    self.running = False
                    break
            
            if not self.running: break

            try:
                if self.ser.in_waiting > 0:
                    data = self.ser.read(self.ser.in_waiting)
                    buffer.extend(data)
                else:
                    time.sleep(0.01)
            except Exception as e:
                self.error_occurred.emit("Read error: " + str(e))
                break

            if self.binary_mode:
                if len(buffer) >= self.expected_bytes:
                    binary_data = buffer[:self.expected_bytes]
                    buffer = buffer[self.expected_bytes:]
                    
                    samples = np.frombuffer(binary_data, dtype=np.int16).copy()
                    self.data_received.emit(samples)
                    
                    self.binary_mode = False
                    self.expected_bytes = 0
            else:
                while b'\n' in buffer:
                    idx = buffer.find(b'\n')
                    line = buffer[:idx].decode('utf-8', errors='ignore').strip()
                    buffer = buffer[idx+1:]
                    
                    if line == "RECORDING_START":
                        self.recording_started.emit()
                    elif line == "RECORDING_END":
                        self.recording_ended.emit()
                    elif line.startswith("DATA_START:"):
                        try:
                            self.expected_bytes = int(line.split(":")[1])
                            self.binary_mode = True
                            break # enter binary loop
                        except:
                            self.error_occurred.emit("Failed to parse DATA_START")
                    elif line.startswith("STATUS:"):
                        pass
                    elif line.startswith("ERROR:"):
                        self.error_occurred.emit("ESP32 Error: " + line[6:])
                    elif line.startswith("INFO:"):
                        pass
                    elif line == "DATA_END":
                        pass
                    elif line == "READY":
                        self.status_updated.emit("ESP32 Ready")
                    else:
                        pass # Ignore other text

        if self.ser and self.ser.is_open:
            self.ser.close()
        self.connected.emit(False)
        self.status_updated.emit("Disconnected")

class BatchRecorder(QThread):
    progress = pyqtSignal(int, int) # current, total
    sample_done = pyqtSignal(str, bool) # filename, success
    status_msg = pyqtSignal(str)
    finished_batch = pyqtSignal()

    def __init__(self, serial_reader):
        super().__init__()
        self.serial = serial_reader
        self.label = ""
        self.count = 0
        self.duration = 5
        self.delay = 1.0
        self.running = False
        
        # We need to wait for binary data from serial
        self.current_data = None
        self.data_event = threading.Event()
        self.serial.data_received.connect(self.on_data)

    def on_data(self, data):
        self.current_data = data
        self.data_event.set()

    def start_batch(self, label, count, duration, delay):
        self.label = label
        self.count = count
        self.duration = duration
        self.delay = delay
        self.start()

    def stop_batch(self):
        self.running = False

    def run(self):
        self.running = True
        self.serial.send_command(f"SET_DURATION:{self.duration}")
        time.sleep(0.5)

        os.makedirs(f"dataset/{self.label}", exist_ok=True)

        for i in range(1, self.count + 1):
            if not self.running: break
            
            self.progress.emit(i, self.count)
            self.status_msg.emit(f"Recording {i}/{self.count}...")
            
            success = False
            retries = 3
            while retries > 0 and self.running:
                self.current_data = None
                self.data_event.clear()
                
                self.serial.send_command("START_RECORDING")
                
                if self.data_event.wait(self.duration + 5.0):
                    data = self.current_data
                    if data is not None and len(data) > 0:
                        # Validate
                        rms = np.sqrt(np.mean(data.astype(np.float32)**2))
                        if rms > 30 and len(data) >= (self.duration * 16000 * 0.8):
                            # Save
                            timestamp = time.strftime("%Y%m%d_%H%M%S")
                            filename = f"dataset/{self.label}/{self.label}_{i:03d}_{timestamp}.wav"
                            try:
                                with wave.open(filename, 'wb') as wf:
                                    wf.setnchannels(NUM_CHANNELS)
                                    wf.setsampwidth(SAMPLE_WIDTH)
                                    wf.setframerate(SAMPLE_RATE)
                                    wf.writeframes(data.tobytes())
                                success = True
                                self.sample_done.emit(filename, True)
                                break
                            except Exception as e:
                                fail_reason = f"File write error: {e}"
                                print(fail_reason)
                        else:
                            fail_reason = f"Validation failed: RMS={rms:.1f}, Length={len(data)}"
                            print(fail_reason)
                    else:
                        fail_reason = "No data received or data empty"
                        print(fail_reason)
                else:
                    fail_reason = "Timeout waiting for data from ESP32"
                    print(fail_reason)
                
                if not success:
                    retries -= 1
                    self.status_msg.emit(f"Retry {3-retries}/3... ({fail_reason})")
                    time.sleep(1.0)
            
            if not success:
                self.sample_done.emit(f"Sample {i} failed: {fail_reason}", False)

            if self.running and i < self.count:
                self.status_msg.emit(f"Waiting {self.delay}s...")
                time.sleep(self.delay)

        self.status_msg.emit("Batch complete" if self.running else "Batch stopped")
        self.finished_batch.emit()

import threading

# ======================================================================
# CUSTOM WIDGETS
# ======================================================================

class LevelMeter(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(20)
        self.level = 0.0
        self.peak = 0.0

    def update_level(self, rms):
        val = min(1.0, rms / 32768.0)
        self.level = val
        if val > self.peak:
            self.peak = val
        else:
            self.peak = max(0.0, self.peak - 0.01)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        rect = self.rect()
        
        painter.fillRect(rect, QColor("#1a1a2e"))
        
        w = int(rect.width() * self.level)
        grad = QLinearGradient(0, 0, rect.width(), 0)
        grad.setColorAt(0.0, QColor("#53d769"))
        grad.setColorAt(0.7, QColor("#ffcc00"))
        grad.setColorAt(1.0, QColor("#ff3b30"))
        
        painter.fillRect(0, 0, w, rect.height(), QBrush(grad))
        
        # Draw peak
        pw = int(rect.width() * self.peak)
        if pw > 0:
            painter.fillRect(pw-2, 0, 2, rect.height(), QColor("#ffffff"))

# ======================================================================
# MAIN WINDOW
# ======================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TinyML Predictive Maintenance - Data Collector")
        self.resize(1000, 700)
        self.setStyleSheet("""
            QMainWindow, QWidget { background-color: #1a1a2e; color: #e0e0e0; }
            QLabel { font-size: 12px; }
            QComboBox, QSpinBox, QDoubleSpinBox { 
                background-color: #0f3460; border: 1px solid #2a2a4e; 
                padding: 4px; border-radius: 4px; 
            }
            QPushButton { 
                background-color: #0f3460; border: 1px solid #2a2a4e; 
                padding: 6px; border-radius: 4px; font-weight: bold;
            }
            QPushButton:hover { background-color: #16213e; }
            QPushButton#btnStart { background-color: #28a745; color: white; }
            QPushButton#btnStart:hover { background-color: #218838; }
            QPushButton#btnStop { background-color: #dc3545; color: white; }
            QPushButton#btnStop:hover { background-color: #c82333; }
            QTreeWidget { background-color: #0f3460; border: 1px solid #2a2a4e; }
            QTreeWidget::item:selected { background-color: #e94560; }
            QProgressBar { text-align: center; background-color: #0f3460; border-radius: 4px; }
            QProgressBar::chunk { background-color: #53d769; }
        """)

        self.serial = SerialReader()
        self.serial.connected.connect(self.on_connected)
        self.serial.data_received.connect(self.on_audio_data)
        self.serial.status_updated.connect(self.lbl_status.setText if hasattr(self, 'lbl_status') else lambda x: None)

        self.recorder = BatchRecorder(self.serial)
        self.recorder.progress.connect(self.on_progress)
        self.recorder.status_msg.connect(self.on_status_msg)
        self.recorder.sample_done.connect(self.on_sample_done)
        self.recorder.finished_batch.connect(self.on_batch_finished)

        self.init_ui()

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)

        # LEFT PANEL
        left_panel = QVBoxLayout()
        main_layout.addLayout(left_panel, 1)

        # Connection
        grp_conn = QVBoxLayout()
        grp_conn.addWidget(QLabel("<b>CONNECTION</b>"))
        
        hbox_port = QHBoxLayout()
        self.cb_port = QComboBox()
        self.refresh_ports()
        hbox_port.addWidget(self.cb_port)
        btn_refresh = QPushButton("↻")
        btn_refresh.setMaximumWidth(30)
        btn_refresh.clicked.connect(self.refresh_ports)
        hbox_port.addWidget(btn_refresh)
        grp_conn.addLayout(hbox_port)

        self.btn_connect = QPushButton("Connect")
        self.btn_connect.clicked.connect(self.toggle_connection)
        grp_conn.addWidget(self.btn_connect)
        
        self.lbl_status = QLabel("Disconnected")
        grp_conn.addWidget(self.lbl_status)
        
        left_panel.addLayout(grp_conn)
        left_panel.addSpacing(20)

        # Config
        grp_conf = QVBoxLayout()
        grp_conf.addWidget(QLabel("<b>RECORDING CONFIG</b>"))
        
        grp_conf.addWidget(QLabel("Label:"))
        self.cb_label = QComboBox()
        self.cb_label.setEditable(True)
        self.cb_label.addItems(["normal", "loose_bearing", "friction", "misalignment"])
        grp_conf.addWidget(self.cb_label)

        grp_conf.addWidget(QLabel("Samples:"))
        self.sp_count = QSpinBox()
        self.sp_count.setRange(1, 500)
        self.sp_count.setValue(20)
        grp_conf.addWidget(self.sp_count)

        grp_conf.addWidget(QLabel("Duration (s):"))
        self.sp_dur = QSpinBox()
        self.sp_dur.setRange(1, 30)
        self.sp_dur.setValue(5)
        grp_conf.addWidget(self.sp_dur)

        grp_conf.addWidget(QLabel("Delay (s):"))
        self.sp_delay = QDoubleSpinBox()
        self.sp_delay.setRange(0.0, 10.0)
        self.sp_delay.setValue(1.0)
        self.sp_delay.setSingleStep(0.5)
        grp_conf.addWidget(self.sp_delay)

        self.btn_start = QPushButton("▶ START BATCH")
        self.btn_start.setObjectName("btnStart")
        self.btn_start.clicked.connect(self.start_batch)
        grp_conf.addWidget(self.btn_start)

        self.btn_stop = QPushButton("⏹ STOP")
        self.btn_stop.setObjectName("btnStop")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop_batch)
        grp_conf.addWidget(self.btn_stop)

        left_panel.addLayout(grp_conf)
        left_panel.addStretch()

        # RIGHT PANEL
        right_panel = QVBoxLayout()
        main_layout.addLayout(right_panel, 3)

        # Plots
        self.plot_wave = pg.PlotWidget(title="Waveform")
        self.plot_wave.setYRange(-32768, 32767)
        self.curve = self.plot_wave.plot(pen='g')
        right_panel.addWidget(self.plot_wave, 1)

        self.plot_spec = pg.PlotWidget(title="Spectrogram")
        self.img_spec = pg.ImageItem()
        self.plot_spec.addItem(self.img_spec)
        colormap = pg.colormap.get('viridis')
        self.img_spec.setLookupTable(colormap.getLookupTable())
        right_panel.addWidget(self.plot_spec, 1)

        # Meters
        meter_layout = QHBoxLayout()
        self.meter = LevelMeter()
        meter_layout.addWidget(QLabel("Level:"))
        meter_layout.addWidget(self.meter, 1)
        self.lbl_rms = QLabel("RMS: 0")
        meter_layout.addWidget(self.lbl_rms)
        right_panel.addLayout(meter_layout)

        # Progress
        prog_layout = QHBoxLayout()
        self.prog_bar = QProgressBar()
        prog_layout.addWidget(self.prog_bar, 1)
        self.lbl_prog = QLabel("Ready")
        prog_layout.addWidget(self.lbl_prog)
        right_panel.addLayout(prog_layout)

        # Dataset Browser
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Filename", "Status", "Size"])
        right_panel.addWidget(self.tree, 1)

    def refresh_ports(self):
        self.cb_port.clear()
        ports = serial.tools.list_ports.comports()
        for p in ports:
            self.cb_port.addItem(p.device)

    def toggle_connection(self):
        if not self.serial.running:
            port = self.cb_port.currentText()
            if port:
                self.serial.connect_port(port)
        else:
            self.serial.disconnect_port()

    def on_connected(self, connected):
        if connected:
            self.btn_connect.setText("Disconnect")
            self.btn_connect.setStyleSheet("background-color: #dc3545;")
        else:
            self.btn_connect.setText("Connect")
            self.btn_connect.setStyleSheet("")

    def start_batch(self):
        if not self.serial.running:
            QMessageBox.warning(self, "Error", "Connect to ESP32 first!")
            return
            
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.tree.clear()
        
        lbl = self.cb_label.currentText()
        cnt = self.sp_count.value()
        dur = self.sp_dur.value()
        dly = self.sp_delay.value()
        
        self.prog_bar.setMaximum(cnt)
        self.prog_bar.setValue(0)
        
        self.recorder.start_batch(lbl, cnt, dur, dly)

    def stop_batch(self):
        self.recorder.stop_batch()
        self.lbl_prog.setText("Stopping...")

    def on_progress(self, current, total):
        self.prog_bar.setValue(current)

    def on_status_msg(self, msg):
        self.lbl_prog.setText(msg)

    def on_sample_done(self, filename, success):
        item = QTreeWidgetItem(self.tree)
        if success:
            item.setText(0, os.path.basename(filename))
            item.setText(1, "✓ OK")
            if os.path.exists(filename):
                item.setText(2, f"{os.path.getsize(filename)/1024:.1f} KB")
        else:
            item.setText(0, filename) # filename contains the fail reason now
            item.setText(1, "✗ Fail")
            item.setText(2, "-")

    def on_batch_finished(self):
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)

    def on_audio_data(self, samples):
        # Update waveform
        self.curve.setData(samples)
        
        # Update RMS
        rms = np.sqrt(np.mean(samples.astype(np.float32)**2))
        self.lbl_rms.setText(f"RMS: {int(rms)}")
        self.meter.update_level(rms)
        
        # Update spectrogram
        f, t, Sxx = scipy.signal.spectrogram(samples, fs=16000, nperseg=256)
        Sxx_db = 10 * np.log10(Sxx + 1e-10)
        self.img_spec.setImage(Sxx_db.T, autoLevels=True)
        self.img_spec.setRect(pg.QtCore.QRectF(0, 0, len(samples)/16000, 8000))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
