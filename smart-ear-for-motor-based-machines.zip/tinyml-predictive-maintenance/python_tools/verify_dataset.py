"""
============================================================
TinyML Predictive Maintenance - Dataset Verifier
============================================================

Purpose: Verify and analyze collected WAV files before 
         uploading to Edge Impulse.

Usage:
    python verify_dataset.py --datadir ./dataset

Checks:
    - WAV file validity
    - Correct sample rate (16000 Hz)
    - Correct bit depth (16-bit)
    - Correct channels (mono)
    - Duration consistency (~2 seconds)
    - Class balance
    - Audio statistics (min, max, mean, RMS)

Author: TinyML Predictive Maintenance Project
============================================================
"""

import os
import sys
import wave
import struct
import math
import argparse
from collections import defaultdict


def analyze_wav(filepath):
    """Analyze a single WAV file and return its properties."""
    result = {
        "filename": os.path.basename(filepath),
        "valid": False,
        "error": None
    }
    
    try:
        with wave.open(filepath, 'rb') as wf:
            result["channels"] = wf.getnchannels()
            result["sample_width"] = wf.getsampwidth()
            result["sample_rate"] = wf.getframerate()
            result["num_frames"] = wf.getnframes()
            result["duration"] = wf.getnframes() / wf.getframerate()
            result["file_size"] = os.path.getsize(filepath)
            
            # Read audio data for statistics
            raw_data = wf.readframes(wf.getnframes())
            num_samples = len(raw_data) // 2  # 16-bit = 2 bytes
            
            if num_samples > 0:
                samples = struct.unpack(f"<{num_samples}h", raw_data)
                
                result["min_val"] = min(samples)
                result["max_val"] = max(samples)
                result["mean_val"] = sum(samples) / len(samples)
                
                # RMS (volume indicator)
                rms = math.sqrt(sum(s**2 for s in samples) / len(samples))
                result["rms"] = rms
                
                # Check for silence (very low RMS)
                result["is_silent"] = rms < 50
                
                # Check for clipping
                result["is_clipping"] = abs(result["min_val"]) > 32000 or abs(result["max_val"]) > 32000
            
            result["valid"] = True
            
    except Exception as e:
        result["error"] = str(e)
    
    return result


def verify_dataset(data_dir):
    """Verify all WAV files in the dataset directory."""
    print("=" * 70)
    print("  TinyML Predictive Maintenance - Dataset Verifier")
    print("=" * 70)
    print(f"\n  Dataset directory: {data_dir}\n")
    
    if not os.path.exists(data_dir):
        print(f"ERROR: Directory '{data_dir}' does not exist!")
        sys.exit(1)
    
    # Discover classes (subdirectories)
    classes = [d for d in os.listdir(data_dir) 
               if os.path.isdir(os.path.join(data_dir, d))]
    
    if not classes:
        print("ERROR: No class subdirectories found!")
        print("Expected structure:")
        print("  dataset/")
        print("    normal/")
        print("      normal_0001.wav")
        print("    imbalance/")
        print("      imbalance_0001.wav")
        sys.exit(1)
    
    print(f"  Classes found: {', '.join(classes)}\n")
    
    # Analyze each class
    class_stats = {}
    all_issues = []
    
    for cls in sorted(classes):
        cls_dir = os.path.join(data_dir, cls)
        wav_files = sorted([f for f in os.listdir(cls_dir) if f.endswith('.wav')])
        
        print(f"  --- Class: {cls} ({len(wav_files)} files) ---")
        
        if not wav_files:
            print(f"    WARNING: No WAV files found!")
            continue
        
        results = []
        for wf in wav_files:
            filepath = os.path.join(cls_dir, wf)
            result = analyze_wav(filepath)
            results.append(result)
        
        # Compile statistics
        valid = [r for r in results if r["valid"]]
        invalid = [r for r in results if not r["valid"]]
        
        if valid:
            durations = [r["duration"] for r in valid]
            rms_values = [r["rms"] for r in valid]
            silent_count = sum(1 for r in valid if r.get("is_silent", False))
            clipping_count = sum(1 for r in valid if r.get("is_clipping", False))
            
            wrong_rate = sum(1 for r in valid if r["sample_rate"] != 16000)
            wrong_bits = sum(1 for r in valid if r["sample_width"] != 2)
            wrong_channels = sum(1 for r in valid if r["channels"] != 1)
            
            stats = {
                "total": len(wav_files),
                "valid": len(valid),
                "invalid": len(invalid),
                "avg_duration": sum(durations) / len(durations),
                "min_duration": min(durations),
                "max_duration": max(durations),
                "avg_rms": sum(rms_values) / len(rms_values),
                "silent": silent_count,
                "clipping": clipping_count,
                "wrong_rate": wrong_rate,
                "wrong_bits": wrong_bits,
                "wrong_channels": wrong_channels,
            }
            class_stats[cls] = stats
            
            print(f"    Valid files   : {stats['valid']}/{stats['total']}")
            print(f"    Duration      : {stats['min_duration']:.2f}s - {stats['max_duration']:.2f}s (avg: {stats['avg_duration']:.2f}s)")
            print(f"    Avg RMS       : {stats['avg_rms']:.1f}")
            
            # Report issues
            if stats["invalid"] > 0:
                issue = f"  {cls}: {stats['invalid']} invalid files"
                all_issues.append(issue)
                print(f"    [!] Invalid     : {stats['invalid']}")
            
            if stats["silent"] > 0:
                issue = f"  {cls}: {stats['silent']} silent recordings"
                all_issues.append(issue)
                print(f"    [!] Silent      : {stats['silent']}")
            
            if stats["clipping"] > 0:
                issue = f"  {cls}: {stats['clipping']} clipping recordings"
                all_issues.append(issue)
                print(f"    [!] Clipping    : {stats['clipping']}")
            
            if stats["wrong_rate"] > 0:
                issue = f"  {cls}: {stats['wrong_rate']} files with wrong sample rate"
                all_issues.append(issue)
                print(f"    [!] Wrong Rate  : {stats['wrong_rate']}")
        
        print()
    
    # Summary
    print("=" * 70)
    print("  DATASET SUMMARY")
    print("=" * 70)
    
    total_files = sum(s["total"] for s in class_stats.values())
    print(f"\n  Total files  : {total_files}")
    print(f"  Classes      : {len(class_stats)}")
    
    print("\n  Class Distribution:")
    for cls, stats in sorted(class_stats.items()):
      bar_len = int(stats["total"] / max(s["total"] for s in class_stats.values()) * 30)
      bar = "#" * bar_len
      print(f"    {cls:15s}: {stats['total']:4d} files  {bar}")
    
    # Balance check
    counts = [s["total"] for s in class_stats.values()]
    if counts:
        min_count = min(counts)
        max_count = max(counts)
        ratio = min_count / max_count if max_count > 0 else 0
        
        print(f"\n  Balance ratio : {ratio:.2f}", end="")
        if ratio < 0.7:
            print(" [!] IMBALANCED - Consider collecting more data for minority class")
        else:
            print(" [OK] BALANCED")
    
    # Issues
    if all_issues:
        print(f"\n  Issues Found ({len(all_issues)}):")
        for issue in all_issues:
            print(f"    [!] {issue}")
    else:
        print("\n  [OK] No issues found! Dataset looks good for Edge Impulse upload.")
    
    print("\n" + "=" * 70)
    
    # Edge Impulse readiness
    print("\n  EDGE IMPULSE UPLOAD READINESS:")
    ready = True
    
    for cls, stats in class_stats.items():
        if stats["total"] < 20:
            print(f"    [!] Class '{cls}' has only {stats['total']} files. Minimum 20 recommended.")
            ready = False
        if stats["wrong_rate"] > 0:
            print(f"    [FAIL] Class '{cls}' has files with wrong sample rate. Must be 16000 Hz.")
            ready = False
    
    if ready:
        print("    [OK] Dataset is ready for Edge Impulse upload!")
    
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Verify WAV dataset before Edge Impulse upload"
    )
    parser.add_argument(
        "--datadir", type=str, default="./dataset",
        help="Dataset directory (default: ./dataset)"
    )
    
    args = parser.parse_args()
    verify_dataset(args.datadir)


if __name__ == "__main__":
    main()
