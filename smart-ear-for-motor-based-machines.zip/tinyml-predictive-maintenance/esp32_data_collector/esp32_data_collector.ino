/*
 * ============================================================
 * TinyML Predictive Maintenance - Data Collection Sketch
 * ============================================================
 * 
 * Purpose: Capture raw audio from INMP441 I2S microphone into
 *          a RAM buffer, then transmit over Serial for WAV 
 *          file creation on PC.
 *
 * Hardware:
 *   - ESP32 Dev Module
 *   - INMP441 I2S Microphone
 *   - SH1106 1.3" Blue I2C OLED Display (0x3C)
 *
 * INMP441 Connections:
 *   WS  -> GPIO15 (LRCLK)
 *   SCK -> GPIO14 (BCLK)
 *   SD  -> GPIO32 (Data)
 *   L/R -> GND  (Left channel)
 *   VCC -> 3.3V
 *   GND -> GND
 *
 * OLED Connections (SH1106):
 *   SDA -> GPIO21
 *   SCL -> GPIO22
 *   VCC -> 3.3V
 *   GND -> GND
 *
 * Serial Baud Rate: 921600
 * Sample Rate: 16000 Hz
 * Bit Depth: 16-bit
 * Channels: Mono
 * 
 * Protocol:
 *   PC -> ESP32:
 *     START_RECORDING\n
 *     STOP_RECORDING\n
 *     STATUS\n
 *     SET_DURATION:N\n (N in seconds)
 * 
 *   ESP32 -> PC:
 *     READY\n
 *     RECORDING_START\n
 *     DATA_START:<BYTES>\n
 *     <raw bytes>
 *     DATA_END\n
 *     RECORDING_END\n
 *     STATUS:<state>,<rec_count>,<duration>\n
 *     ERROR:<msg>\n
 *     INFO:<msg>\n
 *
 * ============================================================
 */

#include <driver/i2s.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

// ==================== OLED Configuration (SH1106) ===========
#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT  64
#define OLED_RESET     -1
#define OLED_ADDRESS   0x3C

Adafruit_SH1106G display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ==================== I2S Configuration =====================
#define I2S_PORT       I2S_NUM_0
#define I2S_WS         15    // Word Select (LRCLK)
#define I2S_SCK        14    // Serial Clock (BCLK)
#define I2S_SD         32    // Serial Data (DOUT)

#define SAMPLE_RATE    16000  // 16 kHz
#define SAMPLE_BITS    16
#define DMA_BUF_COUNT  8
#define DMA_BUF_LEN    512

// ==================== Recording Settings ====================
uint32_t recordingDurationSec = 5; // Default 5s
#define MAX_DURATION_SEC 10 // Max 10s fits in ~300KB RAM
// Dynamic totals
uint32_t totalSamples = 0;
uint32_t totalBytes = 0;

// ==================== Audio Buffer (in RAM) =================
// No large global buffer needed. We will stream data directly 
// from I2S to Serial to save RAM and allow unlimited durations.

// ==================== State Machine ========================
enum State {
  STATE_IDLE,
  STATE_RECORDING,
  STATE_SENDING
};

State currentState = STATE_IDLE;
int recordingCount = 0;

// ==================== Forward Declarations ===================
void updateDerivedSettings();
void displayBoot();
void displayIdle();
void displayRecording(int percent);
void displaySending();
void displayDone(unsigned long totalMs);
unsigned long captureAndSendAudio();
void handleSerialCommand();

// ==================== Setup =================================
void setup() {
  Serial.begin(921600);
  while (!Serial) { delay(10); }

  // Initial calculation
  updateDerivedSettings();

  // Initialize OLED
  Wire.begin(21, 22);
  if (!display.begin(OLED_ADDRESS, true)) {
    Serial.println("ERROR:OLED allocation failed");
    // continue anyway, maybe headless
  } else {
    displayBoot();
  }

  // I2S config
  const i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT, // INMP441 uses 32-bit slot for 24-bit data
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = DMA_BUF_COUNT,
    .dma_buf_len = DMA_BUF_LEN,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };

  const i2s_pin_config_t pin_config = {
    .bck_io_num = I2S_SCK,
    .ws_io_num = I2S_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = I2S_SD
  };

  esp_err_t err;
  err = i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);
  if (err != ESP_OK) {
    Serial.printf("ERROR:I2S install failed: %d\n", err);
    while(1) { delay(100); }
  }

  err = i2s_set_pin(I2S_PORT, &pin_config);
  if (err != ESP_OK) {
    Serial.printf("ERROR:I2S pin failed: %d\n", err);
    while(1) { delay(100); }
  }

  delay(500); // stabilize

  // Flush initial garbage
  int32_t throwaway[128];
  size_t bytesRead;
  for (int i = 0; i < 10; i++) {
    i2s_read(I2S_PORT, throwaway, sizeof(throwaway), &bytesRead, portMAX_DELAY);
  }

  displayIdle();
  Serial.println("INFO:System initialized");
  Serial.println("READY");
}

void loop() {
  if (currentState == STATE_IDLE) {
    handleSerialCommand();
  }
}

// ==================== Command Handling ======================
void handleSerialCommand() {
  if (Serial.available()) {
    String cmdStr = Serial.readStringUntil('\n');
    cmdStr.trim();
    if (cmdStr.length() == 0) return;

    if (cmdStr == "START_RECORDING") {
      recordingCount++;
      currentState = STATE_RECORDING;
      
      displayRecording(0);
      Serial.println("RECORDING_START");
      
      // Stream audio directly to Serial
      unsigned long totalMs = captureAndSendAudio();
      
      currentState = STATE_IDLE;
      displayDone(totalMs);
      
      Serial.println("RECORDING_END");

    } else if (cmdStr == "STOP_RECORDING") {
      // Handled primarily if implemented asynchronously. For now, simple state reset
      currentState = STATE_IDLE;
      displayIdle();
      Serial.println("INFO:Recording stopped");

    } else if (cmdStr == "STATUS") {
      String stateStr = (currentState == STATE_IDLE) ? "IDLE" : 
                        (currentState == STATE_RECORDING) ? "RECORDING" : "SENDING";
      Serial.printf("STATUS:%s,%d,%d\n", stateStr.c_str(), recordingCount, recordingDurationSec);

    } else if (cmdStr.startsWith("SET_DURATION:")) {
      int newDur = cmdStr.substring(13).toInt();
      if (newDur >= 1 && newDur <= MAX_DURATION_SEC) {
        recordingDurationSec = newDur;
        updateDerivedSettings();
        Serial.printf("INFO:Duration set to %d sec\n", recordingDurationSec);
      } else {
        Serial.printf("ERROR:Invalid duration (1-%d)\n", MAX_DURATION_SEC);
      }
    } else {
      Serial.println("ERROR:Unknown command");
    }
  }
}

void updateDerivedSettings() {
  totalSamples = SAMPLE_RATE * recordingDurationSec;
  totalBytes = totalSamples * sizeof(int16_t);
}

// ==================== Capture & Send Audio =========================
unsigned long captureAndSendAudio() {
  unsigned long startMs = millis();
  size_t samplesCollected = 0;
  size_t bytesRead;

  const size_t CHUNK_SAMPLES = 256;
  int32_t tempBuf[CHUNK_SAMPLES];
  int16_t sendBuf[CHUNK_SAMPLES];

  // Send the DATA_START header
  Serial.printf("DATA_START:%u\n", totalBytes);
  Serial.flush(); // wait for text to clear

  // Update OLED once before tight loop
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("RECORDING...");
  display.printf("Sample: %d\n", recordingCount);
  display.println("Streaming data...");
  display.display();

  // We DO NOT update OLED inside the loop! I2C takes ~30ms, which would drop audio.
  
  while (samplesCollected < totalSamples) {
    size_t samplesToRead = totalSamples - samplesCollected;
    if (samplesToRead > CHUNK_SAMPLES) {
      samplesToRead = CHUNK_SAMPLES;
    }
    
    size_t bytesToRead = samplesToRead * sizeof(int32_t);

    esp_err_t err = i2s_read(I2S_PORT, tempBuf, bytesToRead, &bytesRead, portMAX_DELAY);

    if (err == ESP_OK && bytesRead > 0) {
      size_t samplesRead = bytesRead / sizeof(int32_t);
      for (size_t i = 0; i < samplesRead; i++) {
        // Shift right by 16 to extract MSB-aligned 24-bit data as 16-bit
        sendBuf[i] = (int16_t)(tempBuf[i] >> 16);
      }
      
      // Write binary data directly to serial
      Serial.write((uint8_t*)sendBuf, samplesRead * sizeof(int16_t));
      samplesCollected += samplesRead;
    }
  }

  Serial.flush(); 
  Serial.println("\nDATA_END"); 

  return millis() - startMs;
}

// ==================== OLED Functions ========================
void displayBoot() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(0,0);
  display.println("TinyML Audio");
  display.println("Data Collector");
  display.println("-------------");
  display.println("Baud: 921600");
  display.println("Init...");
  display.display();
}

void displayIdle() {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("READY");
  display.printf("Rec Count: %d\n", recordingCount);
  display.printf("Duration: %ds\n", recordingDurationSec);
  display.display();
}

void displayRecording(int percent) {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("RECORDING");
  display.printf("Sample: %d\n", recordingCount);
  display.printf("Progress: %d%%\n", percent);
  
  // Bar
  display.drawRect(0, 40, 128, 10, SH110X_WHITE);
  display.fillRect(0, 40, (128*percent)/100, 10, SH110X_WHITE);
  display.display();
}

void displaySending() {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("SENDING...");
  display.printf("Sample: %d\n", recordingCount);
  display.printf("Bytes: %d\n", totalBytes);
  display.display();
}

void displayDone(unsigned long totalMs) {
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("DONE");
  display.printf("Sample: %d\n", recordingCount);
  display.printf("Time: %lums\n", totalMs);
  display.display();
}
